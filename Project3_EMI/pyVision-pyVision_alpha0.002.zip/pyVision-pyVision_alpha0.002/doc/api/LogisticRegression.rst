LogisticRegression module
=========================

.. automodule:: LogisticRegression
    :members:
    :undoc-members:
    :show-inheritance:
