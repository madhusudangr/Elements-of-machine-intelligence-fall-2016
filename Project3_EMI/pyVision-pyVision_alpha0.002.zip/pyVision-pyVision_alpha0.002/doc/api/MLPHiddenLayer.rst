MLPHiddenLayer module
=====================

.. automodule:: MLPHiddenLayer
    :members:
    :undoc-members:
    :show-inheritance:
