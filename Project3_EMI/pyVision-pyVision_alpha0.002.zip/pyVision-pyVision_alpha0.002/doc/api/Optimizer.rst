Optimizer module
================

.. automodule:: Optimizer
    :members:
    :undoc-members:
    :show-inheritance:
